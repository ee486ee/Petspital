package com.or.petspital.product.service;

import java.util.List;


import com.or.petspital.product.vo.ProductVO;


public interface IProductService {

	List<ProductVO> productList();
}
