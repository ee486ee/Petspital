package com.or.petspital.shopping.service;

import java.util.List;

import com.or.petspital.shopping.vo.DetailVO;
import com.or.petspital.shopping.vo.ReplyVO;
import com.or.petspital.shopping.vo.ShoppingVO;

public interface ShoppingService_impl {

	List<ShoppingVO> selectall();
	
	ShoppingVO selectOne(String id);

	List<DetailVO> Detail(String d_Num);
	
	List<ReplyVO> ViewReply(String gdsNum);
	
	void DeleteReply(String repNum);
	
	void InsertReply(ReplyVO replyVO);

}
