package com.or.petspital.reserve.vo;

public class Reservation {

	private int res_num;
	private String res_id;
	private String res_date;
	private String res_time;
	private String res_memo;
	
	public int getRes_num() {
		return res_num;
	}
	public void setRes_num(int res_num) {
		this.res_num = res_num;
	}
	public String getRes_id() {
		return res_id;
	}
	public void setRes_id(String res_id) {
		this.res_id = res_id;
	}
	public String getRes_date() {
		return res_date;
	}
	public void setRes_date(String res_date) {
		this.res_date = res_date;
	}
	public String getRes_time() {
		return res_time;
	}
	public void setRes_time(String res_time) {
		this.res_time = res_time;
	}
	public String getRes_memo() {
		return res_memo;
	}
	public void setRes_memo(String res_memo) {
		this.res_memo = res_memo;
	}
	
}
